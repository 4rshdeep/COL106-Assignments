public class Node {
	String str;
	int key;

	public Node(int d, String s) {
		str = s;
		key = d;
	}
}